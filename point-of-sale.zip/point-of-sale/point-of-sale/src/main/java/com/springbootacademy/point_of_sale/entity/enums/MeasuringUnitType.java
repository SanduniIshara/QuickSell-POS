package com.springbootacademy.point_of_sale.entity.enums;

public enum MeasuringUnitType {
    KILO_GRAM, LITER, GRAM, NUMBER,MILI_LITER
}
