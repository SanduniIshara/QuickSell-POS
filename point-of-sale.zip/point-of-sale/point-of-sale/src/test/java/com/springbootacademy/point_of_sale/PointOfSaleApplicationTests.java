package com.springbootacademy.point_of_sale;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PointOfSaleApplicationTests {

	@Test
	void contextLoads() {
	}

}
